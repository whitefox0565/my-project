package com.finalProject.gym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
